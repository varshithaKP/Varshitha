
let computerNumber;
let guessCount=0;
let userName;
let score=Infinity;
 function generateNumber(){
    let number='';
    while(number.length<4){
        let digit=Math.floor(Math.random()*10);
        if(!number.includes(digit.toString())){
            number +=digit;
        }
    }
return number;

 }

function check(guess){
    let result='';
    for(let i=0;i<guess.length;i++){
    if(guess[i]===computerNumber[i]){
        result+='+';
    }
    else if
    (computerNumber.includes(guess[i])){
result+='-';
    }
}
return result;
}

document.getElementById('startgame').addEventListener('click',()=>{
    document.getElementById('gamearea').style.display='block';
    computerNumber=generateNumber();
    guessCount=0;
    document.getElementById("guesscount").textContent=guessCount;
});
document.getElementById('startgame').addEventListener('click',()=>{
    player=document.getElementById('input').style.display='block';
});

document.getElementById('stopgame').addEventListener('click',()=>{
    const guessinput=document.getElementById('guessinput').value ;
    if(guessinput.length===4 && [...new Set(guessinput)].length===4){
        guessCount++;
        document.getElementById('guesscount').textContent=guessCount;
        let result=checkGuess(guessinput);
        document.getElementById('msg').textContent=result;
        if(result==='++++'){
            document.getElementById('result').textContent=guessCount;
            if(guessCount<score){
                score=guessCount;
            }
            document.getElementById('score').textContent=guess;
            document.getElementById("scorearea").style.display='block';
        }
    }
})
























